<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar</title>
</head>
<body>
    <form class="login-from" action="<?=base_url('aguardarupdetanivel')?>" method="get">
        <h1>Actualizar</h1>
        <div class="input-group span-2">
        <label for="txttipousuario">Código Nivel:</label>
                <input type="text" name="txttipousuario" value="<?=$nivel['cod_nivel_acad']?>" readonly>
        </div>
        <div class="input-group span-2">
        <label for="txtnombre">Nombre:</label>
                <input type="text" name="txtnombre" value="<?=$nivel['nombre']?>">
        </div>
        <div class="input-group span-2">
        <label for="txtdes">Descripción:</label>
                <input type="text" name="txtdes" value="<?=$region['descripcion']?>">
        </div>
        <div class="input-group span-2">
            <input type="submit" name="btnEnviar" value="Guardar datos">
        </div>
    </form>
</body>
</html>