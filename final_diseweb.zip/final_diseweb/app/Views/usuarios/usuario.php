<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<hr/>
<hr/>
    <title>Inicio de sesión</title>
</head>
<body>

    <div class="container-fluid">
        <div class="row">
            <div class="col-4 offset-4">
                
            <center><h1>Inicio de sesión0</h1></center>

            <?php
            if(session('mensaje')){
                echo session('mensaje');
            }
            
            ?>
                <form action="<?=base_url('iniciar')?>" method="get">
                    <div class="mb-3">
                        <label for="txtUsuario" class="form-label">Usuario</label>
                        <input type="text" class="form-control" id="txtUsuario" name="txtUsuario" placeholder="Ingrese usuario">
                    </div>
                    <div class="mb-3">
                        <label for="txtContra" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" id="txtContra" name="txtContra" placeholder="Ingrese contraseña">
                    </div>
                    <div class="mb-3">
                       <center> <input type="submit" class="btn btn-outline-secondary" id="btnIniciar" name="btnIniciar" value="Iniciar sesión"></center>
                    </div>
                    <div class="mb-3">
                       <center> <a href="<?=base_url('cargar_ciudadano')?>">Ciudadanos</a></center>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<hr/>
<hr/>
</body>
</html>