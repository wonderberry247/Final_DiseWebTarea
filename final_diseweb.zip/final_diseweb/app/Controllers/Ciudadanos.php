<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Ciudadano;
class Ciudadanos extends Controller{
    public function cargarCiudadanos(){
        $ciudadanos = new Ciudadano();
        
        $datos['ciudadano'] = $ciudadanos-> orderBy('dpi' , 'ASC')->findAll();
            return view('operador/ciudadanos',$datos);
    }

    public function eliminarCiudadanos($codigo=null){
        $ciudadanos=new Ciudadano();

        $ciudadanos->delete($codigo);

        $datos['ciudadano']=$ciudadanos->orderBy('dpi', 'ASC')->findAll();
        return view('operador/ciudadanos',$datos);
    }

    public function cargarformulaCiudadanos(){
        return view('operador/insert');
    }
    public function guardarnuevoCiudadanos(){
        $ciudadanos = new Ciudadano();

        $txtdpi=$this->request->getVar('txtdpi');
        $txtapellido=$this->request->getVar('txtapellido');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdireccion=$this->request->getVar('txtdireccion');
        $txttelcasa=$this->request->getVar('txttelcasa');
        $txttelmovil=$this->request->getVar('txttelmovil');
        $txtemail=$this->request->getVar('txtemail');
        $txtfechanac=$this->request->getVar('txtfechanac');
        $txtcod_nivel=$this->request->getVar('txtcod_nivel');
        $txtnacimiento=$this->request->getVar('txtnacimiento');

        $datos=[
            'dpi'=>$txtdpi,
            'apellido'=>$txtapellido,
            'nombre'=>$txtnombre,
            'direccion'=>$txtdireccion,
            'tel_casa'=>$txttelcasa,
            'tel_movil'=>$txttelmovil,
            'email'=>$txtemail,
            'fechanac'=>$txtfechanac,
            'cod_nivel_acad'=>$txtcod_nivel,
            'lugar_nacimiento'=>$txtnacimiento
        ];
        $ciudadanos->insert($datos);

        $datos['ciudadano']=$ciudadanos->orderBy('dpi' , 'ASC')->findAll();
        return view('operador/ciudadanos',$datos);    
    }

    public function modificaCiudadanos($codigo=null){
        $ciudadanos = new Ciudadano();

        $datos['ciudadano']=$ciudadanos->where('dpi',$codigo)->first();
            return view('operador/update',$datos);
    }
    public function aguargarmodificadoCiudadanos(){
        $ciudadanos = new Ciudadano();

        $txtdpi=$this->request->getVar('txtdpi');
        $txtapellido=$this->request->getVar('txtapellido');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdireccion=$this->request->getVar('txtdireccion');
        $txttelcasa=$this->request->getVar('txttelcasa');
        $txttelmovil=$this->request->getVar('txttelmovil');
        $txtemail=$this->request->getVar('txtemail');
        $txtfechanac=$this->request->getVar('txtfechanac');
        $txtcod_nivel=$this->request->getVar('txtcod_nivel');
        $txtnacimiento=$this->request->getVar('txtnacimiento');

        $datos=[
            'dpi'=>$txtdpi,
            'apellido'=>$txtapellido,
            'nombre'=>$txtnombre,
            'direccion'=>$txtdireccion,
            'tel_casa'=>$txttelcasa,
            'tel_movil'=>$txttelmovil,
            'email'=>$txtemail,
            'fechanac'=>$txtfechanac,
            'cod_nivel_acad'=>$txtcod_nivel,
            'lugar_nacimiento'=>$txtnacimiento
        ];

        $ciudadanos->update($txtdpi,$datos);

        $datos['ciudadano']=$ciudadanos->orderBy('dpi','ASC')->findAll();
        return view('operador/ciudadanos',$datos);    
    }

    public function inicio(){
        
        $usuario = $this->request->getVar('txtUsuario');
        $contra = $this->request->getVar('txtContra');

        $resultado ="select * from ciudadanos where dpi='". $usuario . "' and contra ='". $contra ."'";
            $conexion =db_connect();

            $ejecutar = $conexion->query($resultado);

            $cantidad = $ejecutar->getNumRows();

                if ($cantidad > 0){
                    $usuario = $ejecutar->getRow(0);

                    if ($usuario== 'txtUsuario' && $contra=='txtContra'){
                        return view('ciudadanos/usuario');

                    }else {
                        return view('usuarios/usuario');
                        echo "regresar al inicio";

                    }
                }else{
                    echo "Datos incorrectos vueva intenrar";
                    return view('usuarios/usuario');

                }
    }

        public function vervistaciudadanos($codigo=null){
            $ciudadanos = new Ciudadano();
    
            $datos['ciudadano']=$ciudadanos->where('dpi',$codigo)->first();
                return view('operador/update');
    }
}