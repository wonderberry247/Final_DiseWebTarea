<?php 
namespace App\Controllers;

use App\Models\Ciudadano;
use CodeIgniter\Controller;

class Gentes extends Controller{
    public function cargarCiudadano(){
        $ciudadanos = new Ciudadano();
        
        $datos['ciudadano'] = $ciudadanos-> orderBy('dpi' , 'ASC')->findAll();
        return view('ciudadanos/ciudadanos', $datos);
    }
}