<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\User;
class Users extends Controller{

    public function iniciarSesion(){
        
        $usuario = $this->request->getVar('txtUsuario');
        $contra = $this->request->getVar('txtContra');

        $resultado ="select * from usuarios where usuario='". $usuario . "' and contra ='". $contra ."'";
            $conexion =db_connect();

            $ejecutar = $conexion->query($resultado);

            $cantidad = $ejecutar->getNumRows();

                if ($cantidad > 0){
                    $usuario = $ejecutar->getRow(0);

                    if ($usuario->tipousuario_id == 1){
                        return view('menu/admi');

                    }elseif ($usuario->tipousuario_id == 2){
                        return view('menu/encargado');

                    }elseif ($usuario->tipousuario_id == 3){
                        return view('menu/operador');

                    }else {
                        return view('usuarios/usuario');
                        echo "regresar al inicio";

                    }
                }else{
                    echo "Datos incorrectos vueva intenrar";
                    return view('usuarios/usuario');

                }
    }

    public function cargarUser(){
        $usuario = new User();
        
        $datos['usuarios'] = $usuario-> orderBy('dpi' , 'ASC')->findAll();
            return view('admi/user',$datos);
    }

    public function eliminarUsuario($codigo=null){
        $usuario = new User();
        $usuario->delete($codigo);
       
        $datos['usuarios']=$usuario->orderBy('dpi','ASC')->findAll();
        return view('admi/user',$datos);
    }
    
    public function verformularioUsuarios(){
        return view('admi/insertuser');
    }
    public function guardarUsuario(){
        $usuario = new User();

        $txttipousuario =$this->request->getVar('txttipousuario');
        $txtnombre =$this->request->getVar('txtnombre');
        $txtpass =$this->request->getVar('txtpass');
        $txttipo =$this->request->getVar('txttipo');

        $datos=[
            'dpi'=>$txttipousuario,
            'usuario'=>$txtnombre,
            'contra'=>$txtpass,
            'tipousuario_id'=>$txttipo
        ];
        $usuario->insert($datos);

        $datos['usuarios']=$usuario->orderBy('dpi' , 'ASC')->findAll();
        return view('admi/user',$datos);
    }

    public function frmModificarUsuarios($codigo=null){
        $usuario = new User();
        $datos['user']=$usuario->where('dpi',$codigo)->first();
        return view('admi/updateuser',$datos);
    }
    public function modificarUsuarios(){

        $usuario = new User();

        $txttipousuario =$this->request->getVar('txttipousuario');
        $txtnombre =$this->request->getVar('txtnombre');
        $txtpass =$this->request->getVar('txtpass');
        $txttipo =$this->request->getVar('txttipo');

        $datos=[
            'usuario'=>$txtnombre,
            'contra'=>$txtpass,
            'tipousuario_id'=>$txttipo
        ];
        $usuario->update($txttipousuario,$datos);

        
        $datos['usuarios']=$usuario->orderBy('dpi','ASC')->findAll();
        return view('admi/user',$datos);
    }
}