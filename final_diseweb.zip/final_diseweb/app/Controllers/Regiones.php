<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Region;
class Regiones extends Controller{
    public function cargarRegion(){
        $regiones = new Region();
        
        $datos['region'] = $regiones-> orderBy('cod_region' , 'ASC')->findAll();
            return view('encargado/region',$datos);
    }

    public function eliminarRegion($codigo=null){
        $regiones = new Region();
        $regiones->delete($codigo);
       
        $datos['region']=$regiones->orderBy('cod_region','ASC')->findAll();
        return view('encargado/region',$datos);
    }

    public function cargarformularRegion(){
        return view('encargado/insertregion');
    }
    public function guardarnuevoRegion(){
        $municipios = new Region();

        $txttipo=$this->request->getVar('txttipousuario');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdes=$this->request->getVar('txtdes');

        $datos=[
            'cod_region'=>$txttipo,
            'nombre'=>$txtnombre,
            'descripcion'=>$txtdes
        ];
        $municipios->insert($datos);

        $datos['region']=$municipios->orderBy('cod_region','ASC')->findAll();
        return view('encargado/region',$datos);
    }

    public function modificarRegion($codigo=null){
        $municipios = new Region();

        $datos['region']=$municipios->where('cod_region',$codigo)->first();
        return view('encargado/updateregion',$datos);
    }
    public function aguargarmodificadoRegion(){
        $municipios = new Region();

        $txttipo=$this->request->getVar('txttipousuario');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdes=$this->request->getVar('txtdes');

        $datos=[
            'cod_region'=>$txttipo,
            'nombre'=>$txtnombre,
            'descripcion'=>$txtdes
        ];
        $municipios->update($txttipo,$datos);

        
        $datos['region']=$municipios->orderBy('cod_region','ASC')->findAll();
        return view('encargado/region',$datos);
    }
}